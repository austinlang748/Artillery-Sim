/***********************************************************************
 * Heaader File:
 *    Test : Test runner
 * Author:
 *    Br. Helfrich
 * Summary:
 *    The test runner for all the unit tests
 ************************************************************************/

#pragma once

void testRunner();
